var searchData=
[
  ['x_0',['x',['../structquatf__t.html#ad0da36b2558901e21e7a30f6c227a45e',1,'quatf_t::x()'],['../structvec3f__t.html#ad0da36b2558901e21e7a30f6c227a45e',1,'vec3f_t::x()'],['../struct_vk_offset2_d.html#af6d3062751bd565decb1a2cd3b63bdb2',1,'VkOffset2D::x()'],['../struct_vk_offset3_d.html#af6d3062751bd565decb1a2cd3b63bdb2',1,'VkOffset3D::x()'],['../struct_vk_dispatch_indirect_command.html#aae8a40a17c0be29c1f06ca6b4f9e2235',1,'VkDispatchIndirectCommand::x()'],['../struct_vk_viewport.html#ad0da36b2558901e21e7a30f6c227a45e',1,'VkViewport::x()'],['../struct_vk_viewport_swizzle_n_v.html#a2f8dd746aee0906de69fbb28c19daaf2',1,'VkViewportSwizzleNV::x()'],['../struct_vk_x_y_color_e_x_t.html#ad0da36b2558901e21e7a30f6c227a45e',1,'VkXYColorEXT::x()'],['../struct_vk_sample_location_e_x_t.html#ad0da36b2558901e21e7a30f6c227a45e',1,'VkSampleLocationEXT::x()']]],
  ['xchromaoffset_1',['xChromaOffset',['../struct_vk_sampler_ycbcr_conversion_create_info.html#ae335539178bc5ed49bbb48fd33fcd4fd',1,'VkSamplerYcbcrConversionCreateInfo']]],
  ['xcoeff_2',['xcoeff',['../struct_vk_viewport_w_scaling_n_v.html#a9662436f398deb94b938505374ace01d',1,'VkViewportWScalingNV']]]
];
