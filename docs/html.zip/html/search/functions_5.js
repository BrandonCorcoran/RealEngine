var searchData=
[
  ['heap_5falloc_0',['heap_alloc',['../heap_8h.html#a49de2190cff9a4489628dcb9f81b9b66',1,'heap.h']]],
  ['heap_5fcreate_1',['heap_create',['../heap_8h.html#a2f96277dac31fe86acd615a053760f91',1,'heap.h']]],
  ['heap_5fdestroy_2',['heap_destroy',['../heap_8h.html#af8c6e8c6fa5933de699ded23aa83774f',1,'heap.h']]],
  ['heap_5ffree_3',['heap_free',['../heap_8h.html#a1d24a2df5996245973d7711842d55b9d',1,'heap.h']]]
];
