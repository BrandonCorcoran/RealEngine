var searchData=
[
  ['run_5fbits_0',['RUN_BITS',['../lz4_8c.html#ae6261d794dfe7c6816e3b342c643f56f',1,'lz4.c']]],
  ['run_5fmask_1',['RUN_MASK',['../lz4_8c.html#aec45fd08a68c07b74493e631ae52aca1',1,'lz4.c']]]
];
