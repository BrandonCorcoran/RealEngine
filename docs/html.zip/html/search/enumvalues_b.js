var searchData=
[
  ['usingdictctx_0',['usingDictCtx',['../lz4_8c.html#ab22d25a446ad3e8288401052deccda4caf6d955259638feac01c4e4cace77c617',1,'lz4.c']]],
  ['usingextdict_1',['usingExtDict',['../lz4_8c.html#ab22d25a446ad3e8288401052deccda4caa8cc166c33fdfcd904c260136978913b',1,'lz4.c']]]
];
