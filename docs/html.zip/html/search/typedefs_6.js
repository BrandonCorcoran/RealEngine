var searchData=
[
  ['iosurfaceref_0',['IOSurfaceRef',['../vulkan__metal_8h.html#ad208861fd3403603c1dfea8e618782e2',1,'vulkan_metal.h']]]
];
