var searchData=
[
  ['queue_5fmax_0',['QUEUE_MAX',['../lecture7_8c.html#a02effdedef41011bd715e6218b5ec3dc',1,'lecture7.c']]]
];
