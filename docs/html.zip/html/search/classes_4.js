var searchData=
[
  ['net_5faddress_5ft_0',['net_address_t',['../structnet__address__t.html',1,'']]]
];
