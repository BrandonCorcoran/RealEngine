var searchData=
[
  ['debug_5fprint_5ft_0',['debug_print_t',['../debug_8h.html#aaf595fd6dfc2061e76f2b6c904ac0f31',1,'debug.h']]]
];
