var searchData=
[
  ['render_5ft_0',['render_t',['../frogger__game_8h.html#a388e14e920a3886d1adb07f4b3f8143f',1,'render_t():&#160;frogger_game.h'],['../render_8h.html#a388e14e920a3886d1adb07f4b3f8143f',1,'render_t():&#160;render.h'],['../simple__game_8h.html#a388e14e920a3886d1adb07f4b3f8143f',1,'render_t():&#160;simple_game.h']]]
];
