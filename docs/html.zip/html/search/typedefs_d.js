var searchData=
[
  ['semaphore_5ft_0',['semaphore_t',['../semaphore_8h.html#a53c08f13165bc5f076ab3db8f12b8012',1,'semaphore.h']]],
  ['simple_5fgame_5ft_1',['simple_game_t',['../simple__game_8h.html#aed9f36972a2c77c446994d2792a3503f',1,'simple_game.h']]]
];
