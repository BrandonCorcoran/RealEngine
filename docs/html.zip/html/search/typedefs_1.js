var searchData=
[
  ['debug_5fprint_5ft_0',['debug_print_t',['../debug_8h.html#a0215e690b45055ae65c6f8a65927d650',1,'debug.h']]]
];
