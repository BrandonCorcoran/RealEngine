var searchData=
[
  ['nodict_0',['noDict',['../lz4_8c.html#ab22d25a446ad3e8288401052deccda4ca0c48f9478a9b96dcb96a1a8781aba13f',1,'lz4.c']]],
  ['nodictissue_1',['noDictIssue',['../lz4_8c.html#a9f23ad1797bc66e6b6dff6cf3acfd351a2a95ee19c5c0704200f9154a4abcf115',1,'lz4.c']]],
  ['notlimited_2',['notLimited',['../lz4_8c.html#ab93acf685743debab05876250a1cbe28adc568f9214a2932542608f43124efcff',1,'lz4.c']]]
];
