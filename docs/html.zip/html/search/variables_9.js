var searchData=
[
  ['ksize_0',['KSize',['../struct_vk_cooperative_matrix_properties_n_v.html#a2add99f656d1ef90fa3ee7e8e47e6dc6',1,'VkCooperativeMatrixPropertiesNV']]]
];
